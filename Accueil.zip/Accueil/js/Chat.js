// Gestion du chat avec support des nouvelles conversations

// Charger les conversations du localStorage
function loadConversations() {
    const conversations = JSON.parse(localStorage.getItem('chatConversations')) || [];
    return conversations;
}

// Sauvegarder les conversations
function saveConversations(conversations) {
    localStorage.setItem('chatConversations', JSON.stringify(conversations));
}

// Charger les messages d'une conversation
function loadMessages(conversationId) {
    const messages = JSON.parse(localStorage.getItem(`chatMessages_${conversationId}`)) || [];
    return messages;
}

// Sauvegarder les messages d'une conversation
function saveMessages(conversationId, messages) {
    localStorage.setItem(`chatMessages_${conversationId}`, JSON.stringify(messages));
}

// Afficher les conversations
function displayConversations() {
    const conversationsList = document.querySelector('.conversations-list');
    if (!conversationsList) return;
    
    const conversations = loadConversations();
    
    conversationsList.innerHTML = '';
    
    if (conversations.length === 0) {
        conversationsList.innerHTML = `
            <div style="padding: 40px 20px; text-align: center; color: #7f8c8d;">
                <i class="fa-solid fa-comments" style="font-size: 48px; margin-bottom: 15px; color: #bdc3c7;"></i>
                <p style="font-size: 16px; line-height: 1.5;">Aucune conversation pour le moment.<br>Démarrez une nouvelle conversation !</p>
            </div>
        `;
        return;
    }
    
    // Trier par date (les plus récentes en premier)
    conversations.sort((a, b) => new Date(b.lastMessageTime) - new Date(a.lastMessageTime));
    
    conversations.forEach(conv => {
        const conversationItem = document.createElement('div');
        conversationItem.className = 'conversation-item';
        conversationItem.dataset.id = conv.id;
        
        // Calculer le temps
        const time = getTimeDisplay(new Date(conv.lastMessageTime));
        
        conversationItem.innerHTML = `
            <div class="conversation-avatar" style="background-color: ${conv.avatarColor || '#3498db'};">
                <i class="${conv.avatarIcon || 'fa-solid fa-user'}"></i>
            </div>
            <div class="conversation-details">
                <div class="conversation-header">
                    <h3>${conv.userName}</h3>
                    <span class="conversation-time">${time}</span>
                </div>
                <p class="conversation-preview">${conv.lastMessage || 'Aucun message'}</p>
                ${conv.unreadCount > 0 ? `<span class="unread-badge">${conv.unreadCount}</span>` : ''}
            </div>
        `;
        
        conversationItem.addEventListener('click', function() {
            selectConversation(conv.id);
        });
        
        conversationsList.appendChild(conversationItem);
    });
}

// Afficher le temps de manière lisible
function getTimeDisplay(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `${diffMins} min`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays === 1) return 'Hier';
    if (diffDays < 7) return `${diffDays}j`;
    
    return date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
}

// Sélectionner une conversation
function selectConversation(conversationId) {
    const conversations = loadConversations();
    const conversation = conversations.find(c => c.id === conversationId);
    
    if (!conversation) return;
    
    // Marquer comme lu
    conversation.unreadCount = 0;
    saveConversations(conversations);
    
    // Mettre à jour l'UI
    document.querySelectorAll('.conversation-item').forEach(item => {
        item.classList.remove('active');
    });
    
    const activeItem = document.querySelector(`.conversation-item[data-id="${conversationId}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
        const badge = activeItem.querySelector('.unread-badge');
        if (badge) badge.remove();
    }
    
    // Afficher la conversation
    const activeConversation = document.querySelector('.active-conversation');
    const emptyState = document.querySelector('.empty-conversation-state');
    
    if (activeConversation) {
        activeConversation.style.display = 'flex';
        activeConversation.dataset.conversationId = conversationId;
    }
    if (emptyState) emptyState.style.display = 'none';
    
    // Mettre à jour l'en-tête
    const activeUserName = document.querySelector('.active-user h3');
    const activeUserAvatar = document.querySelector('.active-avatar');
    
    if (activeUserName) activeUserName.textContent = conversation.userName;
    if (activeUserAvatar) {
        activeUserAvatar.style.backgroundColor = conversation.avatarColor || '#3498db';
        activeUserAvatar.innerHTML = `<i class="${conversation.avatarIcon || 'fa-solid fa-user'}"></i>`;
    }
    
    // Charger les messages
    displayMessages(conversationId);
}

// Afficher les messages d'une conversation
function displayMessages(conversationId) {
    const messagesContainer = document.querySelector('.messages-container');
    if (!messagesContainer) return;
    
    const messages = loadMessages(conversationId);
    
    messagesContainer.innerHTML = '';
    
    messages.forEach(msg => {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${msg.sender === 'me' ? 'sent' : 'received'}`;
        
        const time = new Date(msg.timestamp).toLocaleTimeString('fr-FR', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${msg.text}</p>
                <span class="message-time">${time}</span>
            </div>
        `;
        
        messagesContainer.appendChild(messageDiv);
    });
    
    // Défiler vers le bas
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Créer une nouvelle conversation
function createNewConversation() {
    const userName = prompt('Entrez le nom du contact :');
    if (!userName || userName.trim() === '') return;
    
    const conversations = loadConversations();
    
    // Générer un ID unique
    const newId = 'conv_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    
    // Couleurs aléatoires pour l'avatar
    const colors = ['#3498db', '#2ecc71', '#9b59b6', '#e74c3c', '#f39c12', '#1abc9c'];
    const icons = [
        'fa-solid fa-user',
        'fa-solid fa-user-tie',
        'fa-solid fa-user-graduate',
        'fa-solid fa-user-nurse',
        'fa-solid fa-user-astronaut'
    ];
    
    const newConversation = {
        id: newId,
        userName: userName.trim(),
        avatarColor: colors[Math.floor(Math.random() * colors.length)],
        avatarIcon: icons[Math.floor(Math.random() * icons.length)],
        lastMessage: '',
        lastMessageTime: new Date().toISOString(),
        unreadCount: 0
    };
    
    conversations.push(newConversation);
    saveConversations(conversations);
    
    // Initialiser les messages vides
    saveMessages(newId, []);
    
    // Rafraîchir l'affichage
    displayConversations();
    
    // Sélectionner la nouvelle conversation
    selectConversation(newId);
}

// Envoyer un message
function sendMessage() {
    const messageInput = document.querySelector('.message-input');
    const activeConversation = document.querySelector('.active-conversation');
    
    if (!messageInput || !activeConversation) return;
    
    const conversationId = activeConversation.dataset.conversationId;
    if (!conversationId) return;
    
    const messageText = messageInput.value.trim();
    if (!messageText) return;
    
    // Créer le message
    const newMessage = {
        id: 'msg_' + Date.now(),
        sender: 'me',
        text: messageText,
        timestamp: new Date().toISOString()
    };
    
    // Sauvegarder le message
    const messages = loadMessages(conversationId);
    messages.push(newMessage);
    saveMessages(conversationId, messages);
    
    // Mettre à jour la conversation
    const conversations = loadConversations();
    const conversation = conversations.find(c => c.id === conversationId);
    if (conversation) {
        conversation.lastMessage = messageText;
        conversation.lastMessageTime = new Date().toISOString();
        saveConversations(conversations);
    }
    
    // Afficher le message
    displayMessages(conversationId);
    
    // Vider l'input
    messageInput.value = '';
    
    // Rafraîchir la liste des conversations
    displayConversations();
    
    // Resélectionner la conversation active
    setTimeout(() => {
        const activeItem = document.querySelector(`.conversation-item[data-id="${conversationId}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }
    }, 100);
}

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    // Afficher les conversations au chargement
    displayConversations();
    
    // Bouton nouvelle conversation
    const newConvBtn = document.querySelector('.new-conversation-btn');
    if (newConvBtn) {
        newConvBtn.addEventListener('click', createNewConversation);
    }
    
    // Rafraîchissement
    const refreshBtn = document.querySelector('.refresh-btn-full');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            this.style.transform = 'rotate(180deg)';
            setTimeout(() => {
                this.style.transform = 'rotate(0deg)';
                displayConversations();
            }, 300);
        });
    }
    
    // Recherche
    const searchInput = document.querySelector('.chat-fullscreen-search input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            
            document.querySelectorAll('.conversation-item').forEach(item => {
                const name = item.querySelector('h3').textContent.toLowerCase();
                const preview = item.querySelector('.conversation-preview').textContent.toLowerCase();
                
                if (name.includes(searchTerm) || preview.includes(searchTerm)) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }
    
    // Envoi de message
    const sendBtn = document.querySelector('.send-btn');
    const messageInput = document.querySelector('.message-input');
    
    if (sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
    }
    
    if (messageInput) {
        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
    
    // Boutons d'action
    document.querySelectorAll('.call-btn, .video-btn, .info-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.classList.contains('call-btn') ? 'Appel' : 
                          this.classList.contains('video-btn') ? 'Vidéo' : 'Info';
            alert(`Fonctionnalité "${action}" - À implémenter`);
        });
    });
    
    // Boutons emoji et pièce jointe
    const emojiBtn = document.querySelector('.emoji-btn');
    const attachBtn = document.querySelector('.attach-btn');
    
    if (emojiBtn) {
        emojiBtn.addEventListener('click', function() {
            alert('Sélecteur d\'emojis - À implémenter');
        });
    }
    
    if (attachBtn) {
        attachBtn.addEventListener('click', function() {
            alert('Pièce jointe - À implémenter');
        });
    }
});