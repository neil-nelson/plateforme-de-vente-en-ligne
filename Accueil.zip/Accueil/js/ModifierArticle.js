// ModifierArticle.js - Gestion de la modification d'articles

document.addEventListener('DOMContentLoaded', function() {
    console.log('ModifierArticle.js chargé');
    
    // Récupérer l'ID de l'article à modifier depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const articleId = urlParams.get('id');
    
    if (!articleId) {
        alert('Aucun article sélectionné pour modification');
        window.location.href = 'dashboard.html';
        return;
    }
    
    // Charger les données de l'article
    loadArticleData(articleId);
    
    // Initialiser les événements
    initEvents(articleId);
});

// Charger les données de l'article
function loadArticleData(articleId) {
    const articles = JSON.parse(localStorage.getItem('secondHandArticles')) || [];
    const article = articles.find(a => a.id == articleId);
    
    if (!article) {
        alert('Article non trouvé');
        window.location.href = 'dashboard.html';
        return;
    }
    
    // Vérifier que l'utilisateur est bien le propriétaire
    const currentUserId = localStorage.getItem('currentUserId');
    if (article.userId !== currentUserId) {
        alert('Vous n\'êtes pas autorisé à modifier cet article');
        window.location.href = 'dashboard.html';
        return;
    }
    
    // Remplir le formulaire avec les données existantes
    document.getElementById('editArticleTitle').value = article.title || '';
    document.getElementById('editArticlePrice').value = article.price || '';
    document.getElementById('editArticleDescription').value = article.description || '';
    document.getElementById('editArticleLocation').value = article.location || '';
    document.getElementById('editArticleContact').value = article.contact || '';
    
    // Catégorie
    const categorySelect = document.getElementById('editArticleCategory');
    if (categorySelect) {
        categorySelect.value = getCategoryName(article.category);
    }
    
    // Sous-catégorie
    initializeSubcategories(article.category, article.subcategory);
    
    // État
    const conditionSelect = document.getElementById('editArticleCondition');
    if (conditionSelect && article.condition) {
        conditionSelect.value = article.condition;
    }
    
    // Livraison
    const deliverySelect = document.getElementById('editArticleDelivery');
    if (deliverySelect && article.deliveryOption) {
        deliverySelect.value = article.deliveryOption;
    }
    
    // Images existantes
    if (article.images && article.images.length > 0) {
        window.existingImages = [...article.images];
        updateImagePreviews();
    }
    
    console.log('Données de l\'article chargées:', article);
}

// Initialiser les sous-catégories
function initializeSubcategories(categoryCode, selectedSubcategory) {
    const subcategories = {
        'Électronique': ['Téléphones', 'Ordinateurs', 'Tablettes', 'Accessoires', 'Jeux vidéo', 'Photo & Vidéo'],
        'Mode': ['Vêtements Hommes', 'Vêtements Femmes', 'Chaussures', 'Accessoires', 'Sacs', 'Bijoux'],
        'Agroalimentaire': ['Fruits & Légumes', 'Produits laitiers', 'Viandes', 'Céréales', 'Produits transformés', 'Boissons'],
        'Immobilier': ['Appartements', 'Maisons', 'Terrains', 'Locaux commerciaux', 'Colocations', 'Bureaux']
    };
    
    const categoryName = getCategoryName(categoryCode);
    const subcategorySelect = document.getElementById('editArticleSubcategory');
    
    if (subcategorySelect && subcategories[categoryName]) {
        subcategorySelect.innerHTML = '<option value="">Sélectionnez une sous-catégorie</option>';
        subcategories[categoryName].forEach(sub => {
            const option = document.createElement('option');
            option.value = sub;
            option.textContent = sub;
            if (sub === selectedSubcategory) {
                option.selected = true;
            }
            subcategorySelect.appendChild(option);
        });
    }
}

// Obtenir le nom de la catégorie à partir du code
function getCategoryName(categoryCode) {
    const map = {
        'elec': 'Électronique',
        'mode': 'Mode',
        'agro': 'Agroalimentaire',
        'immo': 'Immobilier'
    };
    return map[categoryCode] || 'Électronique';
}

// Obtenir le code de la catégorie à partir du nom
function getCategoryCode(categoryName) {
    const map = {
        'Électronique': 'elec',
        'Mode': 'mode',
        'Agroalimentaire': 'agro',
        'Immobilier': 'immo'
    };
    return map[categoryName] || 'elec';
}

// Initialiser les événements
function initEvents(articleId) {
    // Gestion du changement de catégorie
    const categorySelect = document.getElementById('editArticleCategory');
    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            initializeSubcategories(getCategoryCode(this.value), '');
        });
    }
    
    // Gestion des images
    const imageUpload = document.getElementById('editImageUpload');
    const imageInput = document.getElementById('editImageInput');
    
    if (imageUpload && imageInput) {
        imageUpload.addEventListener('click', () => imageInput.click());
        
        imageUpload.addEventListener('dragover', (e) => {
            e.preventDefault();
            imageUpload.classList.add('dragover');
        });
        
        imageUpload.addEventListener('dragleave', () => {
            imageUpload.classList.remove('dragover');
        });
        
        imageUpload.addEventListener('drop', (e) => {
            e.preventDefault();
            imageUpload.classList.remove('dragover');
            handleImageFiles(e.dataTransfer.files);
        });
        
        imageInput.addEventListener('change', (e) => {
            handleImageFiles(e.target.files);
        });
    }
    
    // Validation en temps réel
    const inputs = ['editArticleTitle', 'editArticlePrice', 'editArticleDescription', 
                   'editArticleLocation', 'editArticleContact'];
    
    inputs.forEach(inputId => {
        const input = document.getElementById(inputId);
        if (input) {
            input.addEventListener('input', () => validateForm());
        }
    });
    
    // Bouton d'annulation
    const cancelBtn = document.getElementById('editCancelBtn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            if (confirm('Annuler les modifications ?')) {
                window.location.href = 'dashboard.html#boutiqueBtn';
            }
        });
    }
    
    // Bouton de sauvegarde
    const saveBtn = document.getElementById('editSaveBtn');
    if (saveBtn) {
        saveBtn.addEventListener('click', (e) => {
            e.preventDefault();
            saveArticle(articleId);
        });
    }
}

// Gérer les fichiers images
window.existingImages = [];
window.newImages = [];

function handleImageFiles(files) {
    if (!files || files.length === 0) return;
    
    const totalImages = window.existingImages.length + window.newImages.length + files.length;
    if (totalImages > 10) {
        alert('Maximum 10 images autorisées');
        return;
    }
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        if (!file.type.startsWith('image/')) {
            alert(`${file.name} n'est pas une image valide`);
            continue;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            alert(`${file.name} est trop volumineux (max 5MB)`);
            continue;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            window.newImages.push({
                src: e.target.result,
                name: file.name,
                isNew: true
            });
            updateImagePreviews();
            validateForm();
        };
        reader.readAsDataURL(file);
    }
}

// Mettre à jour les prévisualisations d'images
function updateImagePreviews() {
    const container = document.getElementById('editImagePreviewContainer');
    const uploadText = document.getElementById('editUploadText');
    
    if (!container) return;
    
    container.innerHTML = '';
    const allImages = [...window.existingImages, ...window.newImages];
    
    if (allImages.length === 0) {
        container.innerHTML = `
            <div class="no-images-message">
                <i class="fa-solid fa-image"></i>
                <p>Aucune image sélectionnée</p>
            </div>
        `;
    } else {
        allImages.forEach((img, index) => {
            const div = document.createElement('div');
            div.className = 'image-preview';
            div.innerHTML = `
                <img src="${img.src}" alt="Image ${index + 1}">
                <button type="button" class="remove-image" data-index="${index}" data-new="${img.isNew || false}">
                    <i class="fa-solid fa-times"></i>
                </button>
                ${!img.isNew ? '<div class="existing-badge">Existante</div>' : ''}
            `;
            container.appendChild(div);
        });
        
        // Ajouter les événements de suppression
        document.querySelectorAll('.remove-image').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.currentTarget.dataset.index);
                const isNew = e.currentTarget.dataset.new === 'true';
                
                if (isNew) {
                    window.newImages.splice(index - window.existingImages.length, 1);
                } else {
                    window.existingImages.splice(index, 1);
                }
                updateImagePreviews();
                validateForm();
            });
        });
    }
    
    if (uploadText) {
        uploadText.textContent = allImages.length === 0 
            ? 'Glissez-déposez des images ici ou cliquez pour sélectionner'
            : `Ajouter plus d'images (${allImages.length}/10)`;
    }
}

// Valider le formulaire
function validateForm() {
    const title = document.getElementById('editArticleTitle').value.trim();
    const price = document.getElementById('editArticlePrice').value.trim();
    const description = document.getElementById('editArticleDescription').value.trim();
    const location = document.getElementById('editArticleLocation').value.trim();
    const contact = document.getElementById('editArticleContact').value.trim();
    
    let isValid = true;
    
    // Validation du titre
    if (!title || title.length < 3) {
        showError('editTitleError', 'Le titre doit contenir au moins 3 caractères');
        isValid = false;
    } else {
        clearError('editTitleError');
    }
    
    // Validation du prix
    if (!price || isNaN(price) || parseFloat(price) < 100) {
        showError('editPriceError', 'Veuillez saisir un prix valide (minimum 100 F CFA)');
        isValid = false;
    } else {
        clearError('editPriceError');
    }
    
    // Validation de la description
    if (!description || description.length < 10) {
        showError('editDescriptionError', 'La description doit contenir au moins 10 caractères');
        isValid = false;
    } else {
        clearError('editDescriptionError');
    }
    
    // Validation de la localisation
    if (!location || location.length < 2) {
        showError('editLocationError', 'Veuillez saisir une localisation valide');
        isValid = false;
    } else {
        clearError('editLocationError');
    }
    
    // Validation du contact
    if (!contact || contact.length < 8) {
        showError('editContactError', 'Veuillez saisir un numéro de téléphone valide');
        isValid = false;
    } else {
        clearError('editContactError');
    }
    
    // Validation des images
    const allImages = [...window.existingImages, ...window.newImages];
    if (allImages.length === 0) {
        showError('editImageError', 'Veuillez ajouter au moins une image');
        isValid = false;
    } else {
        clearError('editImageError');
    }
    
    // Activer/désactiver le bouton de sauvegarde
    const saveBtn = document.getElementById('editSaveBtn');
    if (saveBtn) {
        saveBtn.disabled = !isValid;
        saveBtn.style.opacity = isValid ? '1' : '0.5';
        saveBtn.style.cursor = isValid ? 'pointer' : 'not-allowed';
    }
    
    return isValid;
}

// Afficher une erreur
function showError(id, message) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = message;
        element.style.display = 'block';
    }
}

// Effacer une erreur
function clearError(id) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = '';
        element.style.display = 'none';
    }
}

// Sauvegarder les modifications
function saveArticle(articleId) {
    if (!validateForm()) {
        alert('Veuillez corriger les erreurs avant de sauvegarder');
        return;
    }
    
    const articles = JSON.parse(localStorage.getItem('secondHandArticles')) || [];
    const articleIndex = articles.findIndex(a => a.id == articleId);
    
    if (articleIndex === -1) {
        alert('Article non trouvé');
        return;
    }
    
    // Récupérer les valeurs du formulaire
    const updatedArticle = {
        ...articles[articleIndex], // Garder les propriétés existantes
        id: articleId,
        title: document.getElementById('editArticleTitle').value.trim(),
        price: document.getElementById('editArticlePrice').value.trim(),
        description: document.getElementById('editArticleDescription').value.trim(),
        category: getCategoryCode(document.getElementById('editArticleCategory').value),
        subcategory: document.getElementById('editArticleSubcategory').value,
        location: document.getElementById('editArticleLocation').value.trim(),
        contact: document.getElementById('editArticleContact').value.trim(),
        condition: document.getElementById('editArticleCondition').value,
        deliveryOption: document.getElementById('editArticleDelivery').value,
        images: [...window.existingImages, ...window.newImages.map(img => img.src)],
        updatedAt: new Date().toISOString()
    };
    
    // Mettre à jour l'article
    articles[articleIndex] = updatedArticle;
    
    // Sauvegarder dans localStorage
    try {
        localStorage.setItem('secondHandArticles', JSON.stringify(articles));
        
        // Message de succès
        alert('✅ Article modifié avec succès !');
        
        // Redirection vers la boutique
        setTimeout(() => {
            window.location.href = 'dashboard.html?edited=success';
        }, 500);
        
    } catch (error) {
        console.error('Erreur de sauvegarde:', error);
        alert('❌ Erreur lors de la sauvegarde des modifications');
    }
}