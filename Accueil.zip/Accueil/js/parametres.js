// parametres.js - Gestion des paramètres admin
document.addEventListener('DOMContentLoaded', function() {
    console.log('Paramètres.js chargé');
    
    // Charger les paramètres
    loadSettings();
    
    // Initialiser les événements
    initSettingsEvents();
    
    // Charger les statistiques
    updateSettingsStats();
});

function loadSettings() {
    const settings = JSON.parse(localStorage.getItem('adminSettings')) || {
        autoApprove: true,
        emailNotifications: true,
        moderationLog: true,
        deleteLog: true,
        twoFactorAuth: false,
        sessionTimeout: true,
        ipRestriction: false,
        backupFrequency: 'weekly',
        backupRetention: 30
    };
    
    // Appliquer les paramètres aux champs
    const elements = {
        'autoApproveCheck': 'autoApprove',
        'emailNotificationsCheck': 'emailNotifications',
        'moderationLogCheck': 'moderationLog',
        'deleteLogCheck': 'deleteLog',
        'twoFactorCheck': 'twoFactorAuth',
        'sessionTimeoutCheck': 'sessionTimeout',
        'ipRestrictionCheck': 'ipRestriction'
    };
    
    Object.entries(elements).forEach(([id, key]) => {
        const element = document.getElementById(id);
        if (element) {
            element.checked = settings[key] || false;
        }
    });
    
    // Appliquer les sélections
    const backupFrequency = document.getElementById('backupFrequency');
    const backupRetention = document.getElementById('backupRetention');
    
    if (backupFrequency && settings.backupFrequency) {
        backupFrequency.value = settings.backupFrequency;
    }
    
    if (backupRetention && settings.backupRetention) {
        backupRetention.value = settings.backupRetention.toString();
    }
}

function initSettingsEvents() {
    // Sauvegarde des paramètres
    document.getElementById('saveSettingsBtn')?.addEventListener('click', saveSettings);
    
    // Réinitialisation des paramètres
    document.getElementById('resetSettingsBtn')?.addEventListener('click', function() {
        if (confirm('Rétablir tous les paramètres par défaut ?')) {
            localStorage.removeItem('adminSettings');
            loadSettings();
            showNotification('Paramètres réinitialisés avec succès !', 'success');
        }
    });
    
    // Actions de maintenance
    document.getElementById('clearAllArticlesBtn')?.addEventListener('click', function() {
        if (confirm('Êtes-vous sûr de vouloir supprimer TOUTES les annonces ?\n\nCette action est IRREVERSIBLE et supprimera définitivement toutes les annonces.')) {
            clearAllArticles();
        }
    });
    
    document.getElementById('clearOldArticlesBtn')?.addEventListener('click', function() {
        clearOldArticles();
    });
    
    document.getElementById('clearRejectedBtn')?.addEventListener('click', function() {
        clearRejectedArticles();
    });
    
    document.getElementById('optimizeDatabaseBtn')?.addEventListener('click', function() {
        optimizeDatabase();
    });
    
    // Sauvegarde
    document.getElementById('manualBackupBtn')?.addEventListener('click', function() {
        createBackup();
    });
    
    // Sauvegarder automatiquement quand les paramètres changent
    const inputs = document.querySelectorAll('#parametresContent input[type="checkbox"], #parametresContent select');
    inputs.forEach(input => {
        input.addEventListener('change', function() {
            saveSettings();
        });
    });
}

function saveSettings() {
    const settings = {
        autoApprove: document.getElementById('autoApproveCheck').checked,
        emailNotifications: document.getElementById('emailNotificationsCheck').checked,
        moderationLog: document.getElementById('moderationLogCheck').checked,
        deleteLog: document.getElementById('deleteLogCheck').checked,
        twoFactorAuth: document.getElementById('twoFactorCheck').checked,
        sessionTimeout: document.getElementById('sessionTimeoutCheck').checked,
        ipRestriction: document.getElementById('ipRestrictionCheck').checked,
        backupFrequency: document.getElementById('backupFrequency').value,
        backupRetention: parseInt(document.getElementById('backupRetention').value)
    };
    
    localStorage.setItem('adminSettings', JSON.stringify(settings));
    showNotification('Paramètres sauvegardés avec succès !', 'success');
}

function updateSettingsStats() {
    const articles = JSON.parse(localStorage.getItem('secondHandArticles')) || [];
    
    // Calculer les statistiques
    const total = articles.length;
    const pending = articles.filter(a => a.status === 'pending').length;
    const active = articles.filter(a => a.status === 'active' || a.status === 'validated').length;
    const rejected = articles.filter(a => a.status === 'rejected').length;
    
    // Mettre à jour l'affichage
    document.getElementById('totalArticlesCount').textContent = total;
    document.getElementById('pendingArticlesCount').textContent = pending;
    document.getElementById('activeArticlesCount').textContent = active;
    document.getElementById('rejectedArticlesCount').textContent = rejected;
}

function clearAllArticles() {
    // Sauvegarder un backup avant suppression
    createBackup();
    
    // Supprimer toutes les annonces
    localStorage.setItem('secondHandArticles', JSON.stringify([]));
    
    // Mettre à jour les statistiques
    updateSettingsStats();
    updateAdminStats();
    
    // Afficher une notification
    showNotification('Toutes les annonces ont été supprimées avec succès !', 'info');
    
    // Recharger la page admin si on est dans l'admin
    if (window.location.pathname.includes('admin.html')) {
        setTimeout(() => {
            window.location.reload();
        }, 2000);
    }
}

function clearOldArticles() {
    const articles = JSON.parse(localStorage.getItem('secondHandArticles')) || [];
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const oldArticles = articles.filter(article => {
        const articleDate = new Date(article.publishedAt || article.createdAt || Date.now());
        return articleDate < thirtyDaysAgo;
    });
    
    if (oldArticles.length === 0) {
        showNotification('Aucune annonce ancienne à supprimer', 'info');
        return;
    }
    
    if (confirm(`Supprimer ${oldArticles.length} annonces de plus de 30 jours ?`)) {
        const newArticles = articles.filter(article => {
            const articleDate = new Date(article.publishedAt || article.createdAt || Date.now());
            return articleDate >= thirtyDaysAgo;
        });
        
        localStorage.setItem('secondHandArticles', JSON.stringify(newArticles));
        
        showNotification(`${oldArticles.length} annonces anciennes ont été supprimées`, 'success');
        updateSettingsStats();
        updateAdminStats();
    }
}

function clearRejectedArticles() {
    const articles = JSON.parse(localStorage.getItem('secondHandArticles')) || [];
    const rejectedArticles = articles.filter(a => a.status === 'rejected');
    
    if (rejectedArticles.length === 0) {
        showNotification('Aucune annonce rejetée à supprimer', 'info');
        return;
    }
    
    if (confirm(`Supprimer définitivement ${rejectedArticles.length} annonces rejetées ?`)) {
        const newArticles = articles.filter(a => a.status !== 'rejected');
        
        localStorage.setItem('secondHandArticles', JSON.stringify(newArticles));
        
        showNotification(`${rejectedArticles.length} annonces rejetées ont été supprimées`, 'success');
        updateSettingsStats();
        updateAdminStats();
    }
}

function optimizeDatabase() {
    showNotification('Optimisation de la base de données en cours...', 'info');
    
    setTimeout(() => {
        // Simuler l'optimisation
        showNotification('Base de données optimisée avec succès !', 'success');
    }, 1500);
}

function createBackup() {
    const articles = JSON.parse(localStorage.getItem('secondHandArticles')) || [];
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    const backupData = {
        timestamp: new Date().toISOString(),
        articles: articles,
        users: users,
        totalArticles: articles.length,
        totalUsers: users.length
    };
    
    // Créer un fichier de sauvegarde
    const dataStr = JSON.stringify(backupData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `backup_secondmain_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showNotification('✅ Sauvegarde créée avec succès !', 'success');
}

function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notif => notif.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#2ecc71' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10001;
        opacity: 0;
        transform: translateX(100px);
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 500;
    `;
    
    notification.innerHTML = `
        <i class="fa-solid ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100px)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}