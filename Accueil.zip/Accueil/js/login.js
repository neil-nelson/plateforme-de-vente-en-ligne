// login.js - Gestion de la connexion avec déconnexion automatique

document.addEventListener('DOMContentLoaded', function() {
    console.log('Login.js chargé');
    
    const loginForm = document.getElementById('loginForm');
    
    // Vérifier si l'utilisateur est déjà connecté
    checkIfAlreadyLoggedIn();
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('login-username').value.trim();
            const password = document.getElementById('login-password').value;

            // Validation basique
            if (!username || !password) {
                showLoginError('⚠️ Veuillez remplir tous les champs');
                return;
            }

            // Récupérer les utilisateurs du localStorage
            const users = JSON.parse(localStorage.getItem('users')) || [];
            
            // Rechercher l'utilisateur
            const user = users.find(u => u.username === username && u.password === password);

            if (user) {
                // Sauvegarder l'utilisateur connecté
                localStorage.setItem('currentUserId', user.id);
                localStorage.setItem('currentUser', JSON.stringify(user));
                localStorage.setItem('currentUserName', user.firstname || user.username);
                localStorage.setItem('userLoggedIn', 'true');
                localStorage.setItem('lastLogin', new Date().toISOString());
                
                // Message de succès
                showLoginSuccess('✅ Connexion réussie ! Redirection en cours...');
                
                // Redirection vers le dashboard après un délai
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 1500);
            } else {
                // Échec de connexion
                showLoginError('❌ Pseudo ou mot de passe incorrect. Veuillez réessayer.');
                
                // Effacer le mot de passe pour la sécurité
                document.getElementById('login-password').value = '';
                document.getElementById('login-password').focus();
            }
        });
    }

    // Animation au focus des inputs
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
            this.parentElement.style.transition = 'transform 0.2s ease';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });
    
    // Auto-connexion pour le démo (facultatif)
    setupDemoLogin();
});

// Vérifier si l'utilisateur est déjà connecté
function checkIfAlreadyLoggedIn() {
    const currentUserId = localStorage.getItem('currentUserId');
    const userLoggedIn = localStorage.getItem('userLoggedIn');
    
    if (currentUserId && userLoggedIn === 'true') {
        // Rediriger directement vers le dashboard
        console.log('Utilisateur déjà connecté, redirection...');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 100);
    }
}

// Afficher une erreur de connexion
function showLoginError(message) {
    // Supprimer les messages existants
    const existingMessages = document.querySelectorAll('.login-message');
    existingMessages.forEach(msg => msg.remove());
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'login-message login-error';
    errorDiv.style.cssText = `
        background-color: #ffebee;
        color: #c0392b;
        padding: 12px 20px;
        border-radius: 8px;
        margin: 15px 0;
        text-align: center;
        font-weight: 500;
        border: 1px solid #ffcdd2;
        animation: fadeIn 0.3s ease;
    `;
    errorDiv.textContent = message;
    
    const form = document.getElementById('loginForm');
    if (form) {
        form.insertBefore(errorDiv, form.querySelector('.submit-btn'));
    }
}

// Afficher un message de succès
function showLoginSuccess(message) {
    // Supprimer les messages existants
    const existingMessages = document.querySelectorAll('.login-message');
    existingMessages.forEach(msg => msg.remove());
    
    const successDiv = document.createElement('div');
    successDiv.className = 'login-message login-success';
    successDiv.style.cssText = `
        background-color: #d4edda;
        color: #155724;
        padding: 12px 20px;
        border-radius: 8px;
        margin: 15px 0;
        text-align: center;
        font-weight: 500;
        border: 1px solid #c3e6cb;
        animation: fadeIn 0.3s ease;
    `;
    successDiv.textContent = message;
    
    const form = document.getElementById('loginForm');
    if (form) {
        form.insertBefore(successDiv, form.querySelector('.submit-btn'));
    }
    
    // Désactiver le formulaire
    const submitBtn = form.querySelector('.submit-btn');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connexion...';
    }
}

// Configuration de connexion démo (facultatif)
function setupDemoLogin() {
    // Créer un utilisateur de démo si aucun n'existe
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    if (users.length === 0) {
        const demoUser = {
            id: 'demo_user_' + Date.now(),
            firstname: 'John',
            lastname: 'Doe',
            username: 'demo',
            password: 'demo123',
            email: 'demo@secondmain.com',
            phone: '+237 6XX XX XX XX',
            createdAt: new Date().toISOString()
        };
        
        users.push(demoUser);
        localStorage.setItem('users', JSON.stringify(users));
        
        // Ajouter un bouton de connexion démo
        const demoBtn = document.createElement('button');
        demoBtn.type = 'button';
        demoBtn.className = 'demo-login-btn';
        demoBtn.innerHTML = '<i class="fas fa-magic"></i> Connexion démo';
        demoBtn.style.cssText = `
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s ease;
        `;
        
        demoBtn.addEventListener('mouseenter', () => {
            demoBtn.style.transform = 'translateY(-2px)';
            demoBtn.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.4)';
        });
        
        demoBtn.addEventListener('mouseleave', () => {
            demoBtn.style.transform = 'translateY(0)';
            demoBtn.style.boxShadow = 'none';
        });
        
        demoBtn.addEventListener('click', () => {
            document.getElementById('login-username').value = 'demo';
            document.getElementById('login-password').value = 'demo123';
            
            // Déclencher la soumission du formulaire
            const submitEvent = new Event('submit', { cancelable: true });
            document.getElementById('loginForm').dispatchEvent(submitEvent);
        });
        
        const form = document.getElementById('loginForm');
        if (form) {
            form.appendChild(demoBtn);
        }
    }
}