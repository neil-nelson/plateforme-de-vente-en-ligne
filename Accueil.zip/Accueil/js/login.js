// Dans login.js, modifiez la fonction de connexion
document.getElementById('loginForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Récupérer les utilisateurs
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Chercher l'utilisateur
    const user = users.find(u => u.email === email || u.username === email);
    
    if (!user) {
        showMessage('Email ou mot de passe incorrect', 'error');
        return;
    }
    
    // Vérifier le mot de passe (simplifié - en production utiliser bcrypt)
    if (user.password !== password) {
        showMessage('Email ou mot de passe incorrect', 'error');
        return;
    }
    
    // Sauvegarder l'utilisateur connecté
    localStorage.setItem('currentUser', JSON.stringify(user));
    localStorage.setItem('currentUserId', user.id);
    localStorage.setItem('currentUserName', user.firstname || user.username);
    localStorage.setItem('userLoggedIn', 'true');
    
    // Vérifier si c'est un admin
    if (user.isAdmin) {
        showMessage('Connexion admin réussie! Redirection...', 'success');
        setTimeout(() => {
            window.location.href = 'admin.html';
        }, 1500);
    } else {
        showMessage('Connexion réussie! Redirection...', 'success');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
    }
});

// Fonction pour afficher les messages
function showMessage(message, type) {
    const messageDiv = document.getElementById('message');
    if (messageDiv) {
        messageDiv.textContent = message;
        messageDiv.className = `message ${type}`;
        messageDiv.style.display = 'block';
        
        if (type === 'success') {
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 3000);
        }
    }
}