// Profil.js - Gestion du profil utilisateur avec déconnexion

document.addEventListener('DOMContentLoaded', function() {
    console.log('Profil.js chargé');
    
    // Afficher les informations de l'utilisateur
    displayUserProfileInfo();
    
    // Bouton de vérification d'email
    const verifyBtn = document.querySelector('.verify-btn');
    
    if (verifyBtn) {
        verifyBtn.addEventListener('click', function() {
            if (this.textContent === 'Vérifier') {
                this.textContent = 'Vérifié';
                this.style.backgroundColor = '#95a5a6';
                this.disabled = true;
                alert('Un email de vérification a été envoyé à votre adresse.');
            }
        });
    }
    
    // Initialiser le bouton de déconnexion
    initProfileLogoutButton();
});

// Afficher les informations du profil utilisateur
function displayUserProfileInfo() {
    // Récupérer l'utilisateur connecté
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const currentUserId = localStorage.getItem('currentUserId');
    const currentUserName = localStorage.getItem('currentUserName');
    
    // Mettre à jour le nom d'utilisateur
    const userNameElement = document.querySelector('.profil-info h2');
    if (userNameElement) {
        if (currentUser.firstname && currentUser.lastname) {
            userNameElement.textContent = `${currentUser.firstname} ${currentUser.lastname}`;
        } else if (currentUserName) {
            userNameElement.textContent = currentUserName;
        } else {
            userNameElement.textContent = 'Utilisateur';
        }
    }
    
    // Mettre à jour le téléphone
    const phoneElement = document.querySelector('.profil-info p');
    if (phoneElement && currentUser.phone) {
        phoneElement.textContent = currentUser.phone;
    }
    
    // Mettre à jour l'email
    const emailElement = document.querySelector('.email-content p');
    if (emailElement) {
        if (currentUser.email) {
            emailElement.textContent = currentUser.email;
        } else if (currentUser.username) {
            emailElement.textContent = `${currentUser.username}@secondmain.com`;
        }
    }
    
    // Calculer et afficher les statistiques
    updateUserStats(currentUserId);
}

// Mettre à jour les statistiques de l'utilisateur
function updateUserStats(userId) {
    // Récupérer les articles de l'utilisateur
    const articles = JSON.parse(localStorage.getItem('secondHandArticles')) || [];
    const userArticles = articles.filter(article => article.userId === userId);
    
    // Calculer les statistiques
    const stats = {
        vendus: userArticles.filter(a => a.status === 'sold').length,
        achetes: 0, // À implémenter avec un système d'achats
        actives: userArticles.filter(a => a.status === 'active').length,
        vuesTotales: userArticles.reduce((sum, article) => sum + (article.views || 0), 0)
    };
    
    // Mettre à jour l'affichage
    document.querySelector('.profil-stat-vues').textContent = stats.vuesTotales;
    document.querySelector('.user-stat-vendus .user-stat-number').textContent = stats.vendus;
    document.querySelector('.user-stat-achetes .user-stat-number').textContent = stats.achetes;
    document.querySelector('.user-stat-actives .user-stat-number').textContent = stats.actives;
    
    // Données simulées pour les abonnements (à remplacer par des données réelles)
    const userData = {
        abonnees: Math.floor(Math.random() * 100),
        abonnements: Math.floor(Math.random() * 50)
    };
    
    document.querySelector('.profil-stat-abonnees').textContent = userData.abonnees;
    document.querySelector('.profil-stat-abonnements').textContent = userData.abonnements;
}

// Initialiser le bouton de déconnexion dans le profil
function initProfileLogoutButton() {
    const logoutBtn = document.getElementById('profileLogoutBtn');
    if (!logoutBtn) return;
    
    logoutBtn.addEventListener('click', function() {
        if (confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
            // Récupérer le nom de l'utilisateur pour le message
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            const userName = currentUser.firstname || currentUser.username || 'Utilisateur';
            
            // Effacer les données de session
            localStorage.removeItem('currentUserId');
            localStorage.removeItem('currentUserName');
            localStorage.removeItem('currentUser');
            localStorage.removeItem('userLoggedIn');
            localStorage.removeItem('userToken');
            
            // Effacer les données spécifiques si nécessaire
            localStorage.removeItem('userArticles');
            localStorage.removeItem('userStats');
            
            // Message de confirmation
            alert(`À bientôt ${userName} ! Vous avez été déconnecté avec succès.`);
            
            // Redirection vers la page de connexion
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 500);
        }
    });
}

// Exposer les fonctions globalement
window.displayUserProfileInfo = displayUserProfileInfo;
window.updateUserStats = updateUserStats;